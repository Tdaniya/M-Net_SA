function [sim] = lorentzian_similarity(P,Q)
sim=sum(1+abs(P-Q))
end

