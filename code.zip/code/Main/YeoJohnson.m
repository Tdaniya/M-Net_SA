function [transformedData] = YeoJohnson(data)
    % Manually apply Yeo-Johnson transformation on the input data
    % data: Input data vector
    % lambda: Transformation parameter (optional, default is to find the optimal one)
    
    % Initialize variables
    transformedData = zeros(size(data));
    
    
    % Apply Yeo-Johnson transformation
    for i = 1:length(data)
        if data(i) >= 0
                transformedData(i) = log(data(i) + 1);
        else
                transformedData(i) = -log(-data(i) + 1);
           
        end
    end
end

% function nll = negloglikelihood(data, lambda)
%     % Compute the negative log-likelihood for Yeo-Johnson transformation
%     transformedData = manualYeoJohnson(data, lambda);
%     % Assuming normal distribution
%     nll = sum((transformedData - mean(transformedData)).^2);
% end
