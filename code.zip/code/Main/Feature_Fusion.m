function [F_new] = Feature_Fusion(data,label,fs)
LSimilarity=[];
for i=1:length(data)
    d=data(:,i);
    ls=lorentzian_similarity(d,label);
    LSimilarity=[LSimilarity;ls];
end
Alpha=DQN(data,label);
T=length(LSimilarity);
F_new=[];l=round(T);
for m=1:length(LSimilarity)
    FF=[];
    for n=1:fs% number of feature to be fused
        summ=0;i=n;j=1;
        while j<1
            summ=summ+(Alpha(m)/j)*(LSimilarity(m));
            if (i+fs)<length(LSimilarity)
                i=i+fs;
            else
                j=j+1;
            end
            j=j+1;
        end
        FF=[FF,summ];
    end 
    F_new=[F_new;FF];

end

