function [Fea] = Feature_Extraction(blockchain_data)


% Tokenize the text data
documents = tokenizedDocument(blockchain_data);

%  Generate n-grams ( bigrams )
ngrams = bagOfNgrams(documents, 'NgramLengths', 2);

%  n-grams
%disp(ngrams.Vocabulary); % Shows the unique n-grams
fea1=ngrams.NumNgrams;      % Shows the frequency of each n-gram in the documents

bag = bagOfWords(documents); % Create a bag-of-words model
tfidfMatrix = tfidf(bag);  % Compute the TF-IDF features

fea2=tfidfMatrix;

Fea=[fea1,fea2];

end

