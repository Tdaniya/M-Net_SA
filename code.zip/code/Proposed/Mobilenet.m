function [predictions,weights] = Mobilenet(data,Label,Ls)
[train_data, test_data] = splitEachLabel(data ,Ls, 'randomized');
[train_Label, test_Label] = splitEachLabel(Label ,Ls, 'randomized');

% Load the pre-trained MobileNetV2 model
net = mobilenetv2;

% Modify the last layers to fit your number of classes
numClasses = numel(categories(train_Label));
lgraph = layerGraph(net);
newClasses = numClasses; % Adjust this to your classes

% Remove the last layers and replace them
lgraph = removeLayers(lgraph, {'ClassificationLayer', 'predictions'});
lgraph = addLayers(lgraph, [
    fullyConnectedLayer(newClasses, 'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10)
    softmaxLayer
    classificationLayer]);

% Connect the new layers
lgraph = connectLayers(lgraph, 'global_average_pooling2d_1', 'fc');


% Set training options
options = trainingOptions('adam', ...
    'MaxEpochs', 10, ... % Increase if necessary
    'MiniBatchSize', 32, ...
    'ValidationData', augmentedValImds, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'training-progress');
fcLayer = net.Layers(end-1); % Adjust as needed based on your model structure

weights = fcLayer.Weight; % Get the weights

% Train the network
net = trainNetwork(train_data, lgraph, options);


% Classify validation images
predictions = classify(net, test_data);
end

