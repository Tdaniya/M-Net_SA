function [Acc,Sen,Spe] = DSA(fu_features,O2,Label,Ls)
features=[];
for i=1:length(fu_features)
    features=[features;fu_features(i)*O2(i)]
[train_data, test_data] = splitEachLabel(features ,Ls, 'randomized');
[train_Label, test_Label] = splitEachLabel(Label ,Ls, 'randomized');
% Define the size of the hidden layers
hiddenLayerSize1 = 100; % Size of first hidden layer
hiddenLayerSize2 = 50;  % Size of second hidden layer
hiddenLayerSize3 = 25;  % Size of third hidden layer

% Create the autoencoders
autoenc1 = trainAutoencoder(train_data, hiddenLayerSize1, ...
    'MaxEpochs', 400, ...
    'L2WeightRegularization', 0.004, ...
    'SparsityProportion', 0.05, ...
    'DecoderTransferFunction', 'purelin', ...
    'TrainingAlgorithm', 'trainscg');

autoenc2 = trainAutoencoder(autoenc1.predict(test_data), hiddenLayerSize2, ...
    'MaxEpochs', 400, ...
    'L2WeightRegularization', 0.004, ...
    'SparsityProportion', 0.05, ...
    'DecoderTransferFunction', 'purelin', ...
    'TrainingAlgorithm', 'trainscg');

autoenc3 = trainAutoencoder(autoenc2.predict(test_data), hiddenLayerSize3, ...
    'MaxEpochs', 400, ...
    'L2WeightRegularization', 0.004, ...
    'SparsityProportion', 0.05, ...
    'DecoderTransferFunction', 'purelin', ...
    'TrainingAlgorithm', 'trainscg');


% Create the deep stacked autoencoder
stackedNet = stack(autoenc1, autoenc2, autoenc3);

% Set training options
options = trainingOptions('adam', ...
    'MaxEpochs', 200, ...
    'MiniBatchSize', 100, ...
    'Verbose', false, ...
    'Plots', 'training-progress');

% Fine-tune the stacked autoencoder
stackedNet = train(stackedNet, train_data, options);

% predict the network
ypred = stackedNet.predict(test_data);

tp=1;tn=1;fn=1;fp=1;
target=test_Label;
uni=unique(target);
for j=1:length(uni)
    c=uni(j);
    for ii=length(ypred)
         if target(ii)==c && ypred(ii)==c
             fp=fp+1;
         elseif target(ii)~=c && ypred(ii)~=c 
             tn=tn+1;
         elseif target(ii)==c && ypred(ii)~=c
              tp=tp+1;
         elseif target(ii)~=c && ypred(ii)==c
             fn=fn+1;
         end
     end
    end
Acc = (tp + tn) / (tp + fp + fn + tn);
Sen=tp/(tp+fn);
Spe=tn/(tn+fp);

end

