function [O2] = Fusion(Feature,O1,Weight)

Alpha=5;
O2=[];
for i=1:length(Feature)
    temp=[];
    for j=1:length(Feature(i,:))
    y=Feature(i,j)*Weight;
    %Applying Fractional Concept
    temp=[temp,Alpha*y+(1/2)*Alpha*O1];
    end
    O2=[O2;temp];
end

end

