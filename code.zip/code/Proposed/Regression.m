function [ypred] =Regression(Data,Label)
[r,c]=size(Label);
Data=Data(1:r,:);

mdl1 = fitlm(Data,Label);
ypred = predict(mdl1,Data);
end

