
addpath(genpath(pwd));

Input_files=dir("Main\Dataset\*\*.txt"); % Load the dataset
nfiles = length(Input_files);    % Number of files found
Label=[];
Overall_Ext_Fea=[];
for ii=1:nfiles
    ii
    path=strsplit(Input_files(ii).folder,'\');
    if path(end)=="malware"
        Label=[Label;1];
    else
        Label=[Label;0];
    end
    filee=fullfile(Input_files(ii).folder,Input_files(ii).name);
    blockchain_data = fopen(filee,'r');
    Ext_Fea=Fearure_Extraction(blockchain_data);  % Feature Extraction 
    Overall_Ext_Fea=[Overall_Ext_Fea;Ext_Fea];
end
fs=5;  % Feature size 
% Data transformation using Yeo-Johnson transformation
[transformedData] = YeoJohnson(Overall_Ext_Fea);
% Feature Fusion using DQN with Lorentzian similarity
[Fused_Feature]=Feature_Fusion(transformedData,Label,fs);

%-------Randsomeware Detection---------------
ls=0.9; % Learning set(%)
[O1,Weight]=Mobilenet(transformedData,Label,ls);
[F]=Fusion(Fused_Feature,O1,Weight);
[O2]=Regression(F,Label);
[ACC,SEN,SPE]=DSA(Fused_Feature,O2,Label,ls);





